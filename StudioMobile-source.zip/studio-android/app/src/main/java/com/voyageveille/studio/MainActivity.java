package com.voyageveille.studio;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.*;
import android.view.*;
import android.content.ActivityNotFoundException;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.*;
import java.util.Base64;

public class MainActivity extends Activity {
    private WebView web;
    private static final int CREATE_FILE = 42;
    private static final int OPEN_FILE = 43;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingName;
    private byte[] pendingData;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebView.setWebContentsDebuggingEnabled(true);
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try { startActivityForResult(intent, OPEN_FILE); }
                catch (ActivityNotFoundException ex) { filePathCallback = null; callback.onReceiveValue(null); Toast.makeText(MainActivity.this, "Aucun sélecteur de fichiers disponible", Toast.LENGTH_LONG).show(); }
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){ return loader.shouldInterceptRequest(r.getUrl()); }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, String u){ return loader.shouldInterceptRequest(Uri.parse(u)); }
        });
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(false); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        web.loadUrl("https://appassets.androidplatform.net/assets/studio.html");
    }
    public class AndroidBridge {
        @JavascriptInterface public void saveBase64(String filename, String base64, String mime){
            try { pendingName=filename; pendingData=Base64.getDecoder().decode(base64); runOnUiThread(()->createFile(mime)); }
            catch(Exception e){ runOnUiThread(()->Toast.makeText(MainActivity.this,"Erreur sauvegarde: "+e.getMessage(),Toast.LENGTH_LONG).show()); }
        }
        @JavascriptInterface public void toast(String s){ runOnUiThread(()->Toast.makeText(MainActivity.this,s,Toast.LENGTH_SHORT).show()); }
    }
    private void createFile(String mime){ Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType(mime==null?"application/octet-stream":mime); i.putExtra(Intent.EXTRA_TITLE,pendingName); startActivityForResult(i,CREATE_FILE); }
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d);
        if (r == OPEN_FILE) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (c == RESULT_OK && d != null) {
                    if (d.getClipData() != null) {
                        int n = d.getClipData().getItemCount(); results = new Uri[n];
                        for (int i=0; i<n; i++) results[i] = d.getClipData().getItemAt(i).getUri();
                    } else if (d.getData() != null) results = new Uri[]{d.getData()};
                }
                filePathCallback.onReceiveValue(results); filePathCallback = null;
            }
            return;
        }
        if(r==CREATE_FILE && c==RESULT_OK && d!=null && pendingData!=null){ try(OutputStream o=getContentResolver().openOutputStream(d.getData())){o.write(pendingData); Toast.makeText(this,"Fichier enregistré",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Erreur: "+e.getMessage(),Toast.LENGTH_LONG).show();} finally {pendingData=null;} } }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
