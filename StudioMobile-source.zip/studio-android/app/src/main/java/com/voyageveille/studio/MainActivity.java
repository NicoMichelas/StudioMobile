package com.voyageveille.studio;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.*;
import android.view.*;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.*;
import java.util.Base64;

public class MainActivity extends Activity {
    private WebView web;
    private static final int CREATE_FILE = 42;
    private String pendingName;
    private byte[] pendingData;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebView.setWebContentsDebuggingEnabled(true);
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){ return loader.shouldInterceptRequest(r.getUrl()); }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, String u){ return loader.shouldInterceptRequest(Uri.parse(u)); }
        });
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(false); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        web.loadUrl("https://appassets.androidplatform.net/assets/studio.html");
    }
    public class AndroidBridge {
        @JavascriptInterface public void saveBase64(String filename, String base64, String mime){
            try { pendingName=filename; pendingData=Base64.getDecoder().decode(base64); runOnUiThread(()->createFile(mime)); }
            catch(Exception e){ runOnUiThread(()->Toast.makeText(MainActivity.this,"Erreur sauvegarde: "+e.getMessage(),Toast.LENGTH_LONG).show()); }
        }
        @JavascriptInterface public void toast(String s){ runOnUiThread(()->Toast.makeText(MainActivity.this,s,Toast.LENGTH_SHORT).show()); }
    }
    private void createFile(String mime){ Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType(mime==null?"application/octet-stream":mime); i.putExtra(Intent.EXTRA_TITLE,pendingName); startActivityForResult(i,CREATE_FILE); }
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(r==CREATE_FILE && c==RESULT_OK && d!=null && pendingData!=null){ try(OutputStream o=getContentResolver().openOutputStream(d.getData())){o.write(pendingData); Toast.makeText(this,"Fichier enregistré",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Erreur: "+e.getMessage(),Toast.LENGTH_LONG).show();} finally {pendingData=null;} } }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
