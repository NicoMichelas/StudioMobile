# Studio Mobile

Android shell for the Studio editor. The editor is loaded from app assets through WebViewAssetLoader, and FFmpeg WASM is bundled into the APK by CI. After installation, the app does not need internet for editing/export.

## Build
The GitHub Actions workflow downloads @ffmpeg/ffmpeg 0.12.15 and @ffmpeg/core 0.12.10 during the build, bundles them into the APK, and produces a debug APK artifact.

The editor keeps the self-contained project format: media are embedded in the exported project HTML, so a recipient does not need the original media files.
