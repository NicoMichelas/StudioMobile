# StudioMobile — démarrage depuis Android et GitHub

## Ce que contient cette archive

Le dossier `studio-android/` contient un prototype Android (Java + WebView) et l'éditeur HTML intégré. Le but de ce premier dépôt est de vérifier que le projet Android se compile via GitHub Actions et que l'APK peut être récupéré sur le téléphone.

**Important : cette archive n'est pas une application validée prête à l'emploi.** L'interface de l'éditeur est intégrée, mais les fonctions natives d'enregistrement/téléchargement et l'export vidéo doivent encore être testées sur un vrai appareil. Ne l'utilise pas comme unique copie de tes projets.

## Mise en route rapide

1. Dans le dépôt GitHub `NicoMichelas/StudioMobile`, téléverse ce fichier ZIP à la racine du dépôt. Garde le dépôt privé.
2. Dans GitHub, ouvre `Add file` → `Create new file`.
3. Dans le nom du fichier, saisis exactement `.github/workflows/build-apk.yml`.
4. Télécharge puis ouvre le fichier `build-apk.yml` fourni séparément avec cette archive, copie tout son contenu et colle-le dans ce nouvel éditeur GitHub.
5. Valide avec `Commit changes`.
6. Ouvre l'onglet `Actions`, puis le workflow `Build Studio Mobile APK`. Attends que l'exécution soit terminée avec une coche verte.
7. Ouvre l'exécution réussie, descends jusqu'à `Artifacts`, puis télécharge `StudioMobile-debug`. Décompresse l'archive téléchargée pour obtenir `app-debug.apk`.
8. Ouvre `app-debug.apk` sur ton téléphone et autorise l'installation depuis cette source si Android le demande.

Si le workflow échoue, envoie-moi une capture d'écran de l'étape rouge et son journal. Ne publie pas de mot de passe, de clé ou de jeton.
