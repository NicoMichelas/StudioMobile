# Studio Mobile — correctif import / sauvegarde Android

Cette version corrige deux fonctions absentes du conteneur Android :
- le sélecteur natif Android pour ajouter plusieurs photos/vidéos et ouvrir un projet HTML autonome ;
- la sauvegarde native via le sélecteur « Enregistrer sous », pour le projet HTML et l'export MP4.

## Mise à jour dans GitHub
1. Téléverser ce ZIP dans le dépôt `NicoMichelas/StudioMobile` en remplaçant le fichier `StudioMobile-source.zip` existant (même nom, à la racine).
2. Valider le commit.
3. Dans Actions, ouvrir la nouvelle exécution `Build Studio Mobile APK` déclenchée par le commit.
4. Quand elle réussit, ouvrir le résumé de l'exécution et télécharger l'artefact `StudioMobile-debug`.
5. Décompresser l'artefact, installer `app-debug.apk` sur le téléphone. Si Android propose une mise à jour de Studio Mobile, accepter. Si l'installation échoue pour signature incompatible, désinstaller l'ancienne version puis installer la nouvelle (les données de l'application peuvent être effacées).

## Test prioritaire
1. Appuyer sur Ajouter et choisir une photo puis une vidéo.
2. Appuyer sur Enregistrer / partager le projet ; choisir un dossier et enregistrer `studio-projet.html`.
3. Ouvrir le projet avec le bouton Ouvrir un projet Studio et sélectionner le fichier enregistré.
4. Tester l'export MP4 avec un court clip avant d'essayer des vidéos longues.

Les projets autonomes intègrent les médias et peuvent être partagés comme un fichier HTML. Les vidéos longues et les projets très volumineux peuvent consommer beaucoup de mémoire ; l'export FFmpeg reste à valider sur le téléphone.
